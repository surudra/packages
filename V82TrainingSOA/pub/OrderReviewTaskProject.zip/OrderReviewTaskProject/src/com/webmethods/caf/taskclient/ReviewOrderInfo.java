package com.webmethods.caf.taskclient;


import com.webmethods.caf.faces.data.task.ITaskData;
import com.webmethods.caf.faces.data.ContentProviderException;

/**
 * Task Client bean for 'Review Order Info' task.
 */
public class ReviewOrderInfo extends com.webmethods.caf.faces.data.task.impl.TaskContentProviderExtended {

	private static final long serialVersionUID = 8049505167833172992L;
	
	/**
	 * Globally unique task type id
	 */
	private static final String TASK_TYPE_ID = "9E25F606-AFE9-9237-1B06-4ECFE47C869B";

	/**
	 * Default constructor
	 */
	public ReviewOrderInfo() {
		super();
		setTaskTypeID(TASK_TYPE_ID);
	}
	
	/**
	 * Task Data Object
	 */
	public static class TaskData extends com.webmethods.caf.faces.data.task.impl.TaskData {

		private static final long serialVersionUID = 1000783570642052096L;
		
		public static String[][] FIELD_NAMES = new String[][] {{"orderCanonical", "OrderCanonical"},
		};

		private com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical orderCanonical = null;

		public static final String[] INPUTS = new String[] {"orderCanonical", };

		public static final String[] OUTPUTS = new String[] {};

		public TaskData() {
		}

		public com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical getOrderCanonical()  {
			if (orderCanonical == null) {
				orderCanonical = new com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical();
			}
			return orderCanonical;
		}

		public void setOrderCanonical(com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical orderCanonical)  {
			this.orderCanonical = orderCanonical;
		}
		
	}
	
	/**
	 * Return current task data object
	 * @return current task data
	 */
	public TaskData getTaskData() {
		return (TaskData)getValue(PROPERTY_KEY_TASKDATA);
	}

	/**
	 * Creates new task data object
	 * @return newly created task data object
	 */	
	protected ITaskData newTaskData() throws ContentProviderException {
		return new TaskData();
	}

}