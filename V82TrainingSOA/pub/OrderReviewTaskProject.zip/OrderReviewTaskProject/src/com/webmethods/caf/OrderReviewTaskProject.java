/**
 * 
 */
package com.webmethods.caf;

/**
 * @author Administrator
 *
 */
public class OrderReviewTaskProject extends com.webmethods.caf.faces.bean.BaseApplicationBean 
{
	public OrderReviewTaskProject()
	{
		super();
		setCategoryName( "CafApplication" );
		setSubCategoryName( "OrderReviewTaskProject" );
	}
}