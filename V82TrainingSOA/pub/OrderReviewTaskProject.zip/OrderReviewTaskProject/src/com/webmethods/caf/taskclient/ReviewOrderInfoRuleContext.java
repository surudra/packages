package com.webmethods.caf.taskclient;

public class ReviewOrderInfoRuleContext  extends  com.webmethods.caf.faces.data.task.impl.BaseTaskRuleContext {
}