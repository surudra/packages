package com.webmethods.caf.is.document;

import java.io.Serializable;

/**
 * IS document wrapper
 */
public  class V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical extends java.lang.Object implements Serializable {

	
	private static final long serialVersionUID = 1L;
	// IS Document type used to generate this class
	public static final String DOCUMENT_TYPE = "V82TrainingSOA.BuildAndDeploy.Docs:OrderCanonical";
	private com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header header = null;
	public static String[][] FIELD_NAMES = new String[][] {{"header", "Header"},{"orderID", "OrderID"},{"transactionID", "TransactionID"},{"orderDate", "OrderDate"},{"totalCost", "TotalCost"},{"isValid", "IsValid"},{"id", "ID"},{"sender", "Sender"},{"receiver", "Receiver"},{"sku", "SKU"},{"quantity", "Quantity"},{"items", "Items"},
	};
	private com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Items[] items = null;
	

	public V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical() {
	}


	/**
	 * IS document wrapper
	 */
	public static class Header extends java.lang.Object implements Serializable {
	
		
		private static final long serialVersionUID = 1L;
		private java.lang.String orderID;
		private java.lang.String transactionID;
		private java.lang.String orderDate;
		private java.lang.String totalCost;
		private java.lang.String isValid;
		private com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Sender sender = null;
		public static String[][] FIELD_NAMES = new String[][] {{"orderID", "OrderID"},{"transactionID", "TransactionID"},{"orderDate", "OrderDate"},{"totalCost", "TotalCost"},{"isValid", "IsValid"},{"id", "ID"},{"sender", "Sender"},{"receiver", "Receiver"},
		};
		private com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Receiver receiver = null;
		
	
		public Header() {
		}


		public java.lang.String getOrderID()  {
			
			return orderID;
		}


		public void setOrderID(java.lang.String orderID)  {
			this.orderID = orderID;
		}


		public java.lang.String getTransactionID()  {
			
			return transactionID;
		}


		public void setTransactionID(java.lang.String transactionID)  {
			this.transactionID = transactionID;
		}


		public java.lang.String getOrderDate()  {
			
			return orderDate;
		}


		public void setOrderDate(java.lang.String orderDate)  {
			this.orderDate = orderDate;
		}


		public java.lang.String getTotalCost()  {
			
			return totalCost;
		}


		public void setTotalCost(java.lang.String totalCost)  {
			this.totalCost = totalCost;
		}


		public java.lang.String getIsValid()  {
			
			return isValid;
		}


		public void setIsValid(java.lang.String isValid)  {
			this.isValid = isValid;
		}


		/**
		 * IS document wrapper
		 */
		public static class Sender extends java.lang.Object implements Serializable {
		
			
			private static final long serialVersionUID = 1L;
			// IS Document type used to generate this class
			public static String[][] FIELD_NAMES = new String[][] {{"id", "ID"},
			};
			private java.lang.String id;
			
		
			public Sender() {
			}


			public java.lang.String getId()  {
				
				return id;
			}


			public void setId(java.lang.String id)  {
				this.id = id;
			}
		
		}


		public com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Sender getSender()  {
			if (sender == null) {
				sender = new com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Sender();
			}
			return sender;
		}


		public void setSender(com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Sender sender)  {
			this.sender = sender;
		}


		/**
		 * IS document wrapper
		 */
		public static class Receiver extends java.lang.Object implements Serializable {
		
			
			private static final long serialVersionUID = 1L;
			// IS Document type used to generate this class
			public static String[][] FIELD_NAMES = new String[][] {{"id", "ID"},
			};
			private java.lang.String id;
			
		
			public Receiver() {
			}


			public java.lang.String getId()  {
				
				return id;
			}


			public void setId(java.lang.String id)  {
				this.id = id;
			}
		
		}


		public com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Receiver getReceiver()  {
			if (receiver == null) {
				receiver = new com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Receiver();
			}
			return receiver;
		}


		public void setReceiver(com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header.Receiver receiver)  {
			this.receiver = receiver;
		}
	
	}


	public com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header getHeader()  {
		if (header == null) {
			header = new com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header();
		}
		return header;
	}


	public void setHeader(com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Header header)  {
		this.header = header;
	}


	/**
	 * IS document wrapper
	 */
	public static class Items extends java.lang.Object implements Serializable {
	
		
		private static final long serialVersionUID = 1L;
		private java.lang.String sku;
		public static String[][] FIELD_NAMES = new String[][] {{"sku", "SKU"},{"quantity", "Quantity"},
		};
		private java.lang.String quantity;
		
	
		public Items() {
		}


		public java.lang.String getSku()  {
			
			return sku;
		}


		public void setSku(java.lang.String sku)  {
			this.sku = sku;
		}


		public java.lang.String getQuantity()  {
			
			return quantity;
		}


		public void setQuantity(java.lang.String quantity)  {
			this.quantity = quantity;
		}
	
	}


	public com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Items[] getItems()  {
		if (items == null) {
			//TODO: create/set default value here
		}
		return items;
	}


	public void setItems(com.webmethods.caf.is.document.V82TrainingSOA_BuildAndDeploy_Docs_OrderCanonical.Items[] items)  {
		this.items = items;
	}

}