package com.webmethods.caf.revieworderinfoinboxresults;


/**
 * Task Search bean for 'Review Order Info' task.
 */
public class ReviewOrderInfoSearchProvider extends com.webmethods.caf.faces.data.task.impl.TaskInboxSearchContentProvider {

	private static final long serialVersionUID = 5844283691821469696L;
	private static final String TASK_TYPE_ID = "9E25F606-AFE9-9237-1B06-4ECFE47C869B";

	public ReviewOrderInfoSearchProvider() {
		super(); // task type id to search
		m_searchQuery = new CustomInboxSearchQuery(); 
	}

	/**
	 * Typed ITaskData getter
	 * @return current task data
	 */
	public com.webmethods.caf.taskclient.ReviewOrderInfo.TaskData getTaskData() {
		return (com.webmethods.caf.taskclient.ReviewOrderInfo.TaskData)getValue(PROPERTY_TASKDATA);
	}

	/**
	 * Typed custom search query
	 */
	public CustomInboxSearchQuery getSearchQuery() {  
		return (CustomInboxSearchQuery)m_searchQuery;
	}

	/**
	 * Custom inbox search query that can be extended
	 **/
	public class CustomInboxSearchQuery extends com.webmethods.caf.faces.data.task.impl.TaskInboxSearchContentProvider.InboxSearchQuery {
		private static final long serialVersionUID = 4624541000210628608L;
		
		public CustomInboxSearchQuery() {
			super();
		}

	}				

}
