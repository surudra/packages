Use these .xml files to test services in REST Client:
"Open Entire Request" button